function tambahBorder() {
  document.getElementById("box").style.border = "3px solid blue";
}

function hapusBorder() {
    document.getElementById("box").style.border = "none";
}

